/**
 * Created by Administrator on 2016/6/13 0013.
 */

//var node = require("nodes/MMDPlugin.node");
//node.Alert("cn", "title", "msg");
