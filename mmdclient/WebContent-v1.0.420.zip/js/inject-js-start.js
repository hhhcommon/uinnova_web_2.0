/**
 * Created by hzy on 2016/5/9 0009.
 */
console.log("inject-js-start.js", window.location.href);
if(window.global){
    console.log("window.global not null");
    if(!global.frame){
        var frame = {
            uBuilderPID: 0,
            setSaveSceneCallback: function(callback){
                frame.saveSceneCallback = callback;
                global.frame.saveSceneCallback = callback;
            },

            setEditCustomBundleLibCallback: function(callback){
                frame.editCustomBundleLibCallback = callback;
                global.frame.editCustomBundleLibCallback = callback;
            },

            setBakeSceneCallback: function(callback){
                frame.bakeSceneCallback = callback;
                global.frame.bakeSceneCallback = callback;
            },
            
            //en or cn
            setCurrentLanguage: function(language){
                //格式化一下
                frame.currentLanguage = language;
                global.frame.currentLanguage = language;
            },

            //注册调试工具快捷键
            regDevToolShortcut: function(){
                var gui = require('nw.gui');
                var option = {
                    key : "Ctrl+F12",
                    active : function() {
                        console.log("Global desktop keyboard shortcut: " + this.key + " active.");
                    },
                    failed : function(msg) {
                        console.log(msg);
                    }
                };
                var shortcut = new gui.Shortcut(option);
                gui.App.registerGlobalHotKey(shortcut);

                shortcut.on('active', function() {
                    console.log("Global desktop keyboard shortcut: " + this.key + " active.");
                    gui.Window.get().showDevTools();
                });

                shortcut.on('failed', function(msg) {
                    console.log(msg);
                });
            },

            //最小化窗口
            minWindow: function(){
                var gui = require('nw.gui');
                var win = gui.Window.get();
                win.minimize();
            },

            //是否为最大化，可以通过事件监听，记录，进行判定
            //最大化窗口
            maxWindow: function(){
                var gui = require('nw.gui');
                var win = gui.Window.get();
                win.maximize();
            },

            //还原窗口
            restoreWindow: function(){
                var gui = require('nw.gui');
                var win = gui.Window.get();
                win.restore();
            },

            //关闭窗口
            closeWindow: function(){
                var gui = require('nw.gui');
                var win = gui.Window.get();
                win.close();
            },

            //启动子进程
            startChildProcess: function(filePath){
                var execFile =  require('child_process').execFile;
                var file = filePath;
                var child = execFile(file, null, null, function(error, stdout, stderr){
                    //console.log('error: ' + error);
                    console.log('stdout: ' + stdout);
                    console.log('stderr: ' + stderr);
                });
                return child;
            },

            stopChildProcess: function(child){
                if(child && !child.killed && child.kill){
                    child.kill();
                }
            },

            //读取文件全部内容
            readFile: function(filePath){
                var fs = require('fs');
                var content = fs.readFileSync(filePath,"utf-8");
                return content;
            },

            //向文件中写入内容
            writeFile: function(filePath, content) {
                var fs = require('fs');
                fs.writeFileSync(filePath, content, "utf-8");
            },

            renameFile: function(oldPath, newPath){
                var fs = require('fs');
                fs.renameSync(oldPath, newPath);
            },

            createDir: function(path){
                var fs = require('fs');
                var pa = require("path");
                function create(path){
                    if(fs.existsSync(path)){
                        return true;
                    }else{
                        if(create(pa.dirname(path))){
                            fs.mkdirSync(path);
                            return true;
                        }
                    }
                }
                create(path);
            },

            existPath: function(path){
                var fs = require('fs');
                return fs.existsSync(path);
            },

            //启动uBuilder，允许多次调用
            startUBuilder: function(){
                console.log("startUBuilder");
                var node = require("nodes/MMDPlugin.node");
                //暂时这个路径要相对于nwjs.exe
                return node.StartUBuilder("../uBuilder/uBuilder.exe");
            },

            //UBuilder是否正在运行
            uBuilderRunning:function(pid){
                var node = require("nodes/MMDPlugin.node");
                return node.UBuilderRunning(pid);
            },

            //停止UBuilder
            stopUBuilder: function(pid){
                var node = require("nodes/MMDPlugin.node");
                node.StopUBuilder(pid);
            },

            //激活UBuilder
            setUBuilderForground: function(pid){
                var node = require("nodes/MMDPlugin.node");
                node.SetUBuilderForground(pid);
            },

            sendToClient: function(c, msg){
                var data = msg;
                if(typeof msg == "object")
                    data = JSON.stringify(msg);

                var len = Buffer.byteLength(data);

                //写入2个字节表示本次包长
                var headBuf = new Buffer(4);
                headBuf.writeUInt32BE(len, 0)
                c.write(headBuf);

                var bodyBuf = new Buffer(len);
                bodyBuf.write(data);
                c.write(bodyBuf);
            },

            //启动服务器
            startServer: function(){
                var net = require('net');
                var ExBuffer = require('ExBuffer');

                function newConnection(c){
                    var exBuffer = new ExBuffer().uint32Head();
                    exBuffer.on("data", function(buffer){
                        //收到的数据
                        debugger;
                        console.log(buffer.toString());
                        frame.onMessageReceive(c, buffer.toString());
                    });
                    exBuffer.on("error", function(e){
                        console.log(e);
                    });
                    c.on('end', function() {
                        console.log('end');
                        clear();
                    });
                    c.on("data", function(data){
                        debugger;
                        exBuffer.put(data);
                    })
                    c.on("error", function(data){
                        console.log("error");
                        clear();
                    })
                    c.on("close", function(data){
                        console.log("close");
                        clear();
                    })
                    function clear(){
                        if(frame.socket){
                            for(var key in frame.socket){
                                if(frame.socket[key] == c){
                                    delete frame.socket[key];
                                }
                            }
                        }
                    }
                }

                var server = net.createServer();
                server.on("connection", function(c) { //'connection' listener
                    console.log("new socket client connect");
                    new newConnection(c);
                });
                server.listen(46804, function() { //'listening' listener
                    console.log('server bound');
                });
            },

            onMessageReceive: function(c, json){
                debugger;
                var obj = JSON.parse(json);
                console.log("receive message:", obj);
                switch(obj.type)
                {
                    case "SaveSceneMessage": {
                        //保存场景
                        var sceneId = obj.sceneId;
                        var scentName = obj.sceneName;
                        var sceneContent = frame.readFile("../uBuilder/uBuilder_Data/StreamingAssets/Scenes/scene.json");
                        var screenShot = frame.readFile("../uBuilder/uBuilder_Data/StreamingAssets/Scenes/screenshot.txt");
                        if(frame.saveSceneCallback){
                            frame.saveSceneCallback(sceneId, scentName, sceneContent, screenShot, function(result){
                                //result success or failed
                                frame.sendToClient(c, {type: "SaveSceneMessageCallback", result: result.success});
                            });
                        }
                        break;
                    }
                    case "EditCustomBundleLibMessage": {
                        if(frame.editCustomBundleLibCallback){
                            frame.editCustomBundleLibCallback();
                        }
                        var gui = require('nw.gui');
                        var win = gui.Window.get();
                        win.setAlwaysOnTop(true);
                        win.setAlwaysOnTop(false);
                        win.show();
                        win.focus();
                        break;
                    }
                    case "BakeSceneMessage": {
                        if(frame.bakeSceneCallback){
                            frame.bakeSceneCallback();
                        }
                        var sceneId = obj.sceneId;
                        var filePath = obj.filePath;
                        frame.bakeScene(sceneId, filePath);
                    }
                    case "HelloMessage": {
                        console.log(obj.clientName + " connnected");
                        if(!frame.socket) frame.socket = {};
                        frame.socket[obj.clientName] = c;
                    }
                    default: break;
                }
            },

            downloadFile: function(fileUrl, progressCallback, endCallback){
                var fs = require('fs');
                var url = require('url');
                var http = require('http');
                var gui = require('nw.gui');
                var win = gui.Window.get();
                var urlObj = url.parse(fileUrl);
                var options = {
                    host: urlObj.host,
                    path: urlObj.pathname
                };
                var filename = urlObj.pathname.split('/').pop();
                if(filename.indexOf(".") == -1) filename += ".zip";
                var win = gui.Window.get();
                var document = win.window.document;
                var save = document.createElement("input");
                save.setAttribute("type", "file");
                save.setAttribute("nwsaveas", filename);
                save.click();
                save.addEventListener("change", function(){
                    var savePath = save.value;
                    if(savePath){
                        console.log(savePath);
                        var tempFileName = savePath + ".TMP";
                        var file = fs.createWriteStream(tempFileName);

                        http.get(fileUrl, function(res) {
                            var fsize = res.headers['content-length'];
                            var lastTime = 0;
                            var interval = 1 * 1000;
                            res.on('data', function(data) {
                                file.write(data);
                                var nowTime = new Date();
                                if((nowTime - lastTime) > interval){
                                    var ret = {};
                                    if(fsize){
                                        var percent = parseInt((file.bytesWritten / fsize) * 100);
                                        win.setProgressBar(percent/100);
                                        ret = {type: "percent", percent: percent, bytesWritten: file.bytesWritten, fileUrl: fileUrl};
                                    }
                                    else{
                                        ret = {type: "bytesWritten", bytesWritten: file.bytesWritten, fileUrl: fileUrl};
                                    }
                                    if(progressCallback){
                                        progressCallback(ret);
                                    }
                                    console.log(ret);
                                    lastTime = nowTime;
                                }
                            }).on('end', function() {
                                file.end();
                                fs.renameSync(tempFileName, savePath);
                                win.setProgressBar(-1);
                                /*if(progressCallback){
                                 progressCallback(100);
                                 }*/
                                if(endCallback){
                                    endCallback(fileUrl);
                                }
                            });
                        });
                    }
                })
            },

            createScene: function(configObj){
                if(frame.uBuilderRunning(frame.uBuilderPID)){
                    frame.alert(frame.languageMap.getText("Close3DSceneFirst"));
                }
                else{
                    var dir = "../uBuilder/uBuilder_Data/StreamingAssets/Scenes/";
                    if(!frame.existPath(dir)){
                        frame.createDir(dir);
                    }
                    configObj.action = "new";
                    configObj.mmdClient = true;
                    frame.writeFile("../uBuilder/DevConfig.json", JSON.stringify(configObj));
                    frame.uBuilderPID = frame.startUBuilder();
                }
            },

            editScene: function(sceneJSON, configObj){
                if(frame.uBuilderRunning(frame.uBuilderPID)){
                    frame.alert(frame.languageMap.getText("Close3DSceneFirst"));
                }
                else{
                    var dir = "../uBuilder/uBuilder_Data/StreamingAssets/Scenes/";
                    if(!frame.existPath(dir)){
                        frame.createDir(dir);
                    }
                    frame.writeFile(dir + "scene.json", sceneJSON);
                    configObj.action = "edit";
                    configObj.mmdClient = true;
                    frame.writeFile("../uBuilder/DevConfig.json", JSON.stringify(configObj));
                    console.log("call startUBuilder");
                    frame.uBuilderPID = frame.startUBuilder();
                }
            },

            viewScene: function(sceneJSON, configObj){
                if(frame.uBuilderRunning(frame.uBuilderPID)){
                    frame.alert(frame.languageMap.getText("Close3DSceneFirst"));
                }
                else{
                    var dir = "../uBuilder/uBuilder_Data/StreamingAssets/Scenes/";
                    if(!frame.existPath(dir)){
                        frame.createDir(dir);
                    }
                    frame.writeFile(dir + "scene.json", sceneJSON);
                    configObj.action = "view";
                    configObj.mmdClient = true;
                    frame.writeFile("../uBuilder/DevConfig.json", JSON.stringify(configObj));
                    frame.uBuilderPID = frame.startUBuilder();
                }
            },

            bakeScene: function(sceneId, filePath){
                debugger;
                // function uploadToAliyun(config, filename, filepath, callback) {
                //     var fs = require('fs'),
                //         path = require('path'),
                //         crypto = require('crypto');
                //     var xbase64 = require('xbase64');
                //     var request = require('request');
                //
                //     function hmac_sha1(content, secret) {
                //         return crypto.createHmac('sha1', secret).update(content).digest();
                //     }
                //
                //     if (!filename)
                //         filename = path.basename(filepath);
                //
                //     var policy = {
                //         "expiration": (new Date(Date.now() + 360000)).toISOString(),
                //         "conditions": [{
                //             key: filename
                //         }]
                //     };
                //     var encodedPolicy = xbase64.encode(JSON.stringify(policy));
                //     var encodedSign = xbase64.encode(hmac_sha1(encodedPolicy, config.accessKeySecret));
                //     var formData = {
                //         key: filename,
                //         OSSAccessKeyId: config.accessKeyId,
                //         policy: encodedPolicy,
                //         Signature: encodedSign,
                //         success_action_status: 200,
                //         file: fs.createReadStream(filepath)
                //     };
                //     request.post({
                //         url: config.url,
                //         formData: formData
                //     }, function(err, resp, body) {
                //         if (err)
                //             callback(err);
                //         else if (resp.statusCode == 200)
                //             callback(null);
                //         else
                //             callback(new Error('status: ' + resp.statusCode + ', error: ' + body));
                //     });
                // }

                var fileName = sceneId + ".json";
                var zipName = sceneId + ".zip";
                var key = "json/" + zipName;
                var oldPath = "../uBuilder/uBuilder_Data/StreamingAssets/Export/export_max.json";
                var newPath = "../uBuilder/uBuilder_Data/StreamingAssets/Export/" + fileName;
                var zipPath = "../uBuilder/uBuilder_Data/StreamingAssets/Export/" + zipName;

                //压缩
                frame.renameFile(oldPath, newPath);
                frame.zipFile(newPath, zipPath);

                //上传到测试
                // uploadToAliyun({
                //     url: 'http://hzytest.oss-cn-qingdao.aliyuncs.com',
                //     accessKeyId: 'wslLvNLvATQ325AW',
                //     accessKeySecret: 'fuUiYpwiilGmvQdUf2vSWyJfMvfb3X'
                // }, key, "../uBuilder/uBuilder_Data/StreamingAssets/Export/" + zipName, function(err) {
                //     console.log(err);
                // });

                //上传到正式
                // uploadToAliyun({
                //     url: 'http://scene-baking.oss-cn-beijing.aliyuncs.com',
                //     accessKeyId: '43qSw90Tli0mmjOl',
                //     accessKeySecret: 'jFVdPdHUpp7QZYGA0Hnu8dSRV0IgpU'
                // }, key, '../uBuilder/uBuilder_Data/StreamingAssets/Export/export_max.json', function(err) {
                //     console.log(err);
                // });

                frame.jquery.ajax({
                    url: frame.config["server-head"] + "aliOSSToken/STS-" + sceneId,
                    type: "get",
                    dataType: "json",
                    timeout: 5000,
                    data: {},
                    success: function(data){
                        console.log("上传之前获取到的数据", data);
                        if(data.state) {
                            data = data.content;
                            var accessKeyId = data.AccessKeyId;
                            var accessKeySecret = data.AccessKeySecret;
                            var securityToken = data.SecurityToken;

                            var accessKeyId = "43qSw90Tli0mmjOl";
                            var accessKeySecret = "jFVdPdHUpp7QZYGA0Hnu8dSRV0IgpU";
                            var co = require('co');
                            var OSS = require('ali-oss')
                            var client = new OSS({
                                region: 'oss-cn-beijing',
                                accessKeyId: accessKeyId,
                                accessKeySecret: accessKeySecret,
                                //stsToken: securityToken,
                                bucket: 'scene-baking'
                            });

                            co(function*() {
                                var result = yield client.put(key, zipPath);
                                console.log(result);
                            }).catch(function (err) {
                                console.log("上传失败", err);
                            });
                        }
                    },
                    error: function(data, a, b){
                        console.log("获取数据失败，烘焙失败");
                    }
                });
            },

            postDebugger: function(url, sceneObj){
                var urlSet = "[Setting]\r\n" + "Url=" + url;
                frame.writeFile("../MMDPostDebugger/Config", urlSet);
                frame.writeFile("../MMDPostDebugger/cmd.json", JSON.stringify(sceneObj, null, 4).replace(/\n/g, "\r\n"));
                return frame.startChildProcess("../MMDPostDebugger/MMDPostDebugger.exe");
            },

            closePostDebugger: function(child){
                frame.stopChildProcess(child);
            },

            alert: function(msg){
                var node = require("nodes/MMDPlugin.node");
                node.Alert(frame.currentLanguage, frame.languageMap.getText("AlertTitle"), msg);
            },
            //return  1: OK, 2: Cancel
            confirm: function(msg){
                var node = require("nodes/MMDPlugin.node");
                return node.Confirm(frame.currentLanguage, frame.languageMap.getText("ConfirmTitle"), msg);
            },

            zipFile: function(src, dec){
                var admZip = require('adm-zip');
                var zip = new admZip();
                zip.addLocalFile(src);
                zip.writeZip(dec);
            },



        }

        frame.languageMap = {
            getText: function(key){
                for(var i = 0; i < frame.languageMap.value.length; i++){
                    if(frame.languageMap.value[i].key == key)
                    {
                        return frame.languageMap.value[i][frame.currentLanguage]? frame.languageMap.value[i][frame.currentLanguage]: frame.languageMap.value[i].cn;
                    }
                }
            },
            value: [
                {key: "CloseConfirm",
                    en: "are you sure?",
                    cn: "真的要退出吗？"},
                {key: "Close3DSceneFirst",
                    en: "Please Close 3D Scene First",
                    cn: "请先关闭已打开的场景！"},
                {key: "AlertTitle",
                    en: "alert",
                    cn: "消息"},
                {key: "ConfirmTitle",
                    en: "confirm",
                    cn: "注意"},
                {key: "WindowDefaultTitle",
                    en: "MMD",
                    cn: "模模搭"}
            ]
        }

        function init(){
            var gui = require('nw.gui');

            //注册快捷键，Ctrl+F12 打开调试工具，发布版应该去掉该快捷键
            frame.regDevToolShortcut();
            //启动服务器，进程间通信
            frame.startServer();

            //关闭窗口时做一些事情
            gui.Window.get().on('close', function() {
                //这里可以弹出提示框，是否要退出
                var ret = frame.confirm(frame.languageMap.getText("CloseConfirm"));
                if(ret == 1){
                    if(frame.uBuilderRunning(frame.uBuilderPID)){
                        frame.setUBuilderForground(frame.uBuilderPID);
                        frame.stopUBuilder(frame.uBuilderPID);
                    }

                    // After closing the new window, close the main window.
                    this.hide();
                    //清空缓存，还不知道管不管用
                    gui.App.clearCache();
                    this.close(true);
                }
            });

            //初始化配置
            frame.config = gui.App.manifest.config;

            //jquery的支持
            frame.jquery = require("jquery.min.js");
            var XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;
            frame.jquery.support.cors = true;
            frame.jquery.ajaxSettings.xhr = function() {
                return new XMLHttpRequest();
            };
        }

        init();

        //可以通过以下方法交换数据
        console.log("set frame");
        global.frame = frame;
        window.frame = frame;
    } else {
        window.frame = global.frame;
    }
}
else{
    try{
        window.frame = window.top.frame;
    }
    catch (e){

    }
}