/**
 * Created by Administrator on 2016/6/14 0014.
 */

console.log("inject-js-end.js", window.location.href);
if(window.global){
    if(!document.title){
        document.title = global.frame.languageMap.getText("WindowDefaultTitle");
    }
}

//屏蔽backspace,backspace 偶尔会崩溃
document.onkeydown = function(e){
    if ((event.keyCode==8) ) //屏蔽退格删除键
    {
        var tag = window.event.srcElement.tagName.toUpperCase();
        if (tag != "INPUT" && tag != "TEXTAREA" && tag != "TEXT")
        {
            event.keyCode=0;
            event.returnValue=false;
        }
    }
}

window.oldOpen = window.open;
window.open = function(a, b, c){
    setTimeout(function(){
        window.oldOpen(a, b, c);
    }, 0)
}


